"""Run the complete local evaluation and record its checkpoints."""

import hashlib
import json
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parent
REPOSITORY = ROOT.parents[1]
HELPER = REPOSITORY / "skills/rustify/scripts/project.py"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    records = []
    commands = [
        ("fmt", ["cargo", "fmt", "--check"], ROOT / "replacement"),
        ("clippy", ["cargo", "clippy", "--all-targets", "--", "-D", "warnings"], ROOT / "replacement"),
        ("test", ["cargo", "test", "--locked"], ROOT / "replacement"),
        ("build", ["cargo", "build", "--locked"], ROOT / "replacement"),
        ("comparison", [sys.executable, "evaluate.py", "--record-scenarios"], ROOT),
    ]
    for name, command, directory in commands:
        result = subprocess.run(command, cwd=directory, capture_output=True, timeout=180)
        log = ROOT / f"evidence/check-{name}.log"
        log.write_bytes(result.stdout + result.stderr)
        records.append({"name": name, "command": command, "directory": str(directory), "returncode": result.returncode, "log": str(log.relative_to(ROOT)), "log_sha256": sha(log)})
        print(name, result.returncode)
        if result.returncode:
            print((result.stdout + result.stderr).decode(errors="replace"))
            return result.returncode
    candidate = ROOT / "replacement/target/debug/xh"
    (ROOT / "checks.json").write_text(json.dumps({"status": "passed", "commands": records, "candidate_sha256": sha(candidate)}, indent=2) + "\n")
    for _ in range(5):
        status = json.loads(subprocess.check_output([sys.executable, str(HELPER), "status", str(ROOT)]))
        if status["next"] is None:
            break
        subprocess.run([sys.executable, str(HELPER), "checkpoint", str(ROOT), status["next"]], check=True, capture_output=True)
    source = [path for path in (ROOT / "replacement").rglob("*") if path.is_file() and "target" not in path.relative_to(ROOT).parts and path.suffix in {".rs", ".toml", ".lock"}]
    models = [ROOT / name for name in ("contract.json", "product.md", "experience.md", "recovered-architecture.md", "evidence.json", "rust-design.md", "plan.json", "scenarios.json")]
    scripts = [ROOT / name for name in ("fixture.py", "evaluate.py", "verify.py")]
    freeze = {"source_access": "The reconstruction has not received upstream source or tests.", "files": {path.relative_to(ROOT).as_posix(): sha(path) for path in sorted(source + models + scripts)}, "candidate_sha256": sha(candidate), "target_sha256": sha(ROOT.parent / "downloads/xh")}
    (ROOT / "freeze.json").write_text(json.dumps(freeze, indent=2) + "\n")
    print(subprocess.check_output([sys.executable, str(HELPER), "status", str(ROOT)]).decode())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
