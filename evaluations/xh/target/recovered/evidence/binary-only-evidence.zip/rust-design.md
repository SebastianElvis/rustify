# Rust replacement design

The replacement uses Tokio for async execution.
The replacement uses reqwest for HTTP transport and redirect handling.
The replacement uses serde_json with insertion-order preservation for JSON bodies.
The Cargo lockfile records the selected versions.

The command parses only the scoped CLI options.
A typed request model separates parsing from execution.
Typed errors distinguish input, transport, JSON, and output failures.
The HTTP client has a five-second timeout and no proxy.
The URL guard accepts only the loopback HTTP host `127.0.0.1`.
The redirect guard also rejects an external destination.

The command uses the observed `xh/0.26.3` User-Agent for protocol compatibility.
The HTTP library supplies framing, header validation, and redirect mechanics.
The replacement does not implement an HTTP parser or transport.
The replacement keeps all logic in one small module.

Unit tests cover request construction and status mapping.
Process E2E tests use a Python loopback fixture server.
The protocol report compares request method, path, selected headers, and body bytes.
The process report compares exact stdout, stderr, exit status, and files.

The evaluation permits header order and transport defaults to differ.
The raw request report retains those differences for review.
