import base64, json, os, subprocess, tempfile
from pathlib import Path
BINARY=Path(__file__).resolve().parents[1]/'downloads/b3sum'
ROOT=Path(__file__).resolve().parent
b64=lambda x: base64.b64encode(x).decode()
cases=[]
def case(name,args,data=b'',files=None):
 cases.append({'id':name,'args':args,'stdin_b64':b64(data),'files':{k:b64(v) for k,v in (files or {}).items()}})
case('help',['--help'])
case('version',['--version'])
case('empty',[])
case('hello',[],b'hello')
case('names',['a','b','-'],b'stdin',{'a':b'aaa','b':b'bbb'})
case('missing',['absent'])
case('missing-then-good',['absent','a'],files={'a':b'aaa'})
case('directory',['directory'],files={'directory/a':b'a'})
case('no-names',['--no-names','a','b'],files={'a':b'aaa','b':b'bbb'})
case('raw',['--raw'],b'hello')
case('raw-many',['--raw','a','b'],files={'a':b'aaa','b':b'bbb'})
case('length0',['-l','0'],b'hello')
case('length1',['-l','1'],b'hello')
case('length65',['--length=65','--seek=63'],b'hello')
case('tag',['--tag','a'],files={'a':b'aaa'})
case('escaped',['a\\b','a\nb'],files={'a\\b':b'aaa','a\nb':b'bbb'})
case('derive',['--derive-key','my context'],b'hello')
case('keyed',['--keyed','a'],bytes(range(32)),{'a':b'hello'})
case('keyed-short',['--keyed','a'],b'x',{'a':b'hello'})
case('keyed-long',['--keyed','a'],b'x'*33,{'a':b'hello'})
case('keyed-stdin',['--keyed'],b'x'*32)
case('invalid-length',['-l','bad'])
case('quiet-not-check',['--quiet'])
case('check-empty',['--check'],b'')
case('check-malformed',['--check'],b'garbage\n')
case('check-missing',['--check'],b'0'*64+b'  missing\n')
case('check-mismatch',['--check'],b'0'*64+b'  a\n',{'a':b'hello'})
case('check-valid',['--check'],b'ea8f163db38682925e4491c5e58d4bb3506ef8c14eb78a86e908c5624a67200f  a\n',{'a':b'hello'})
case('check-quiet',['--check','--quiet'],b'ea8f163db38682925e4491c5e58d4bb3506ef8c14eb78a86e908c5624a67200f  a\n',{'a':b'hello'})
case('check-prefix',['--check'],b'ea8f163db3868292  a\n',{'a':b'hello'})
records=[]
for c in cases:
 with tempfile.TemporaryDirectory() as d:
  for name,data in c['files'].items():
   p=Path(d)/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(base64.b64decode(data))
  r=subprocess.run(['b3sum',*c['args']],executable=BINARY,input=base64.b64decode(c['stdin_b64']),cwd=d,env={'LC_ALL':'C','PATH':'/usr/bin:/bin'},capture_output=True)
  records.append({'case':c,'returncode':r.returncode,'stdout_b64':b64(r.stdout),'stderr_b64':b64(r.stderr)})
  print(c['id'],r.returncode,repr(r.stdout[:240]),repr(r.stderr[:400]))
(ROOT/'evidence/runtime.json').write_text(json.dumps(records,indent=2)+'\n')
(ROOT/'discovery-cases.json').write_text(json.dumps(cases,indent=2)+'\n')
