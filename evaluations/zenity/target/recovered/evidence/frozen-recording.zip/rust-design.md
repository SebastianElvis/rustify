# Rust design

The replacement uses objc2 AppKit bindings for native alerts and text fields.
The code uses safe Rust and runs AppKit on the main thread.
The parser builds typed options before GUI work.
The dialog function returns a status and optional text.
The process boundary writes stdout and returns the status.
Tauri 2 adds an unnecessary webview for this small native dialog contract.
Unit tests cover option failures and dialog outcome mapping.
The external native replay verifies actual controls and process results.
