import json,pathlib,base64,random,itertools
p=pathlib.Path(__file__).parent
cases=[]
def add(args,data=b'',files=None,env=None):
 c={'id':f'case-{len(cases):04d}','args':args,'stdin_b64':base64.b64encode(data).decode(),'files':{k:base64.b64encode(v).decode() for k,v in (files or {}).items()}}
 if env:c['env']=env
 cases.append(c)
for f in ['probes.json','more-probes.json']:
 for r in json.loads((p/'evidence'/f).read_text()):add(r['args'],base64.b64decode(r['stdin_b64']))
for size in [0,1,2,3,4,55,56,57,58,59,76,77,255,256,1023,3071,3072,3073,4095,4096,4097,30719,30720,30721,65535]:
 data=bytes(i%256 for i in range(size))
 for w in [None,0,1,2,3,4,5,75,76,77,2147483648]:add([] if w is None else ['-w',str(w)],data)
 enc=base64.b64encode(data)
 for opts in [['-d'],['-di']]:add(opts,enc)
for args,data,files in [(['input'],b'wrong',{'input':b'hello\x00\xff'}),(['-d','input'],b'wrong',{'input':b'aGVsbG8='}),(['input','-w2'],b'wrong',{'input':b'abc'}),(['--','-d'],b'wrong',{'-d':b'abc'}),(['-'],b'abc',{}),(['dir'],b'',{'dir/file':b'abc'}),(['input/child'],b'',{'input':b'abc'}),(['no dir/no file'],b'',{})]:add(args,data,files)
for opt in ['--decode','--ignore-garbage','--wrap','--help','--version']:
 for n in range(3,len(opt)+1):
  a=opt[:n];add([a,'2'] if opt=='--wrap' else [a],b'YQ==')
for name in ['foo bar',"foo'bar",'foo"bar','foo:bar','foo\nbar','foo\\bar','foo\tbar','é',"'",'',"a'\nb"]:
 add([name]);add(['-w',name]);add(['x',name])
for wrap in ['0','-0','+0','2147483647','2147483648','9223372036854775807','9223372036854775808','99999999999999999999999999999','999999999999999999999999999x','-9223372036854775808','\v2','\r2','\f2']:
 add(['-w',wrap],b'abc')
for a in [['--='],['--=x'],['--de=x'],['-iw2'],['-dii'],['-wd'],['-w2d'],['a','-d'],['a','--bad'],['a','--help'],['a','-d','b'],['--','--help'],['-w2','-w3']]:add(a,b'YWJj')
for env in [{'POSIXLY_CORRECT':'1'},{'POSIXLY_CORRECT':''}]:
 for a in [['x','--help'],['x','-d'],['-','-d'],['-w','1']]:add(a,b'YWJj',{'x':b'YWJj'},env)
rng=random.Random(917)
for _ in range(400):
 data=bytes(rng.choice(b'ABRYWQJj01+/=\n\r !\t\x00\xff') for _ in range(rng.randrange(0,60)))
 for opt in [['-d'],['-di']]:add(opt,data)
for pad in [b'',b'=',b'==',b'===',b'\n',b'!',b'A',b'AA']:
 for prefix in [b'YQ',b'YR',b'YWJ',b'YWK',b'YWJj',b'YQ==']:
  for opt in [['-d'],['-di']]:add(opt,prefix+pad)
(p/'scenarios.json').write_text(json.dumps(cases,indent=2)+'\n')
# The binary supplies these exact user-visible strings.
records=json.loads((p/'evidence/probes.json').read_text())
for arg,out in [('--help','help.txt'),('--version','version.txt')]:
 (p/'evidence'/out).write_bytes(base64.b64decode(next(r for r in records if r['args']==[arg])['stdout_b64']))
features=[('encode','The command encodes bytes with the RFC 4648 alphabet.','case-0000'),('decode','The command decodes complete groups and preserves output before an error.','case-0035'),('input','The command reads stdin or one file.','case-0019'),('wrap','The command uses 76 columns by default. Zero disables wrapping. Positive signed overflow also disables wrapping.','case-0017'),('garbage','The command ignores LF. The ignore flag removes other non-alphabet bytes except padding.','case-0034'),('options','The command accepts GNU long option prefixes and short option groups.','case-0004'),('information','The command prints help and version text.','case-0000'),('errors','The command reports option, input, file, read, and write errors.','case-0002')]
evidence=[{'id':'E-'+k,'claim':v,'classification':'observed','source':['evidence/probes.json','evidence/more-probes.json','evidence/names.json'],'limitations':'The captures use finite C locale cases.'} for k,v,_ in features]
evidence += [{'id':'E-architecture','claim':'The binary calls getopt, file I/O, encoder, decoder, and close-output helpers.','classification':'observed','source':'evidence/rea.json','limitations':'The pseudocode can omit machine details.'},{'id':'I-purpose','claim':'The command supports shell pipelines.','classification':'inferred','source':'E-input','limitations':'The test can falsify this claim if stdin and stdout fail in a pipeline.'},{'id':'U-failures','claim':'Allocation failure and signal timing remain unknown.','classification':'unknown','source':'contract.json','limitations':'The investigation does not inject these failures.'}]
(p/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
(p/'product.md').write_text('# Product behavior\n\n'+''.join(f'- `{k}`: {v} The evidence record is `E-{k}`.\n' for k,v,_ in features)+'\nThe binary identifies itself as GNU coreutils 9.12.\nThe help text defines the supported CLI.\nThe product intent remains an inference.\nThe project proposes no new feature.\n')
(p/'experience.md').write_text('''# CLI experience

The command uses `[OPTION]... [FILE]`.
The command writes encoded or decoded bytes to stdout.
The command writes errors to stderr.
The command returns zero for success and one for observed failures.
The command preserves decoded bytes before invalid input.
The command accepts options after operands unless POSIXLY_CORRECT exists.
The command stops option processing at `--`.
The command handles help and version as soon as it parses them.
The help text uses argv[0].
The version text uses the fixed name `base64`.
The project stores exact text in `evidence/help.txt` and `evidence/version.txt`.
The project stores diagnostic captures in `evidence/probes.json` and `evidence/more-probes.json`.
The CLI has no visual design system.
''')
(p/'recovered-architecture.md').write_text('''# Recovered architecture

The shipped artifact is an arm64 Mach-O.
The artifact depends on libSystem.
REA records these facts in `evidence/rea.json`.

The `_main` procedure sets the program name and locale.
The procedure registers `_close_stdout`.
The procedure calls `_rpl_getopt_long` for options.
The procedure opens one file or selects stdin.
The procedure selects `_do_encode` or `_do_decode`.
The encoder reads blocks and calls `_base64_encode`.
The encoder wraps output and checks read and write errors.
The decoder allocates 4096 input bytes and 3072 output bytes.
The decoder can remove garbage before `_base64_decode_ctx`.
The decoder writes partial results before it reports invalid input.
The `_finish_and_exit` and close-output paths finish I/O.

These edges come from observed pseudocode.
The pseudocode does not prove every register value or branch condition.
The project uses probes for acceptance behavior.
The project infers that block processing bounds memory.
A growing resident memory test can falsify this inference.
The exact internal fast path remains outside the recovered model.
''')
print(len(cases))
