import json,pathlib
p=pathlib.Path(__file__).parent
features=[('encode','RFC 4648 bytes and wrap formatting'),('decode','Partial output, padding, pad bits, LF, and concatenated groups'),('input','stdin, dash, file, and file errors'),('wrap','Numeric syntax and overflow'),('garbage','Optional filtering'),('options','GNU parsing, grouping, prefixes, and POSIX mode'),('information','Exact help and version text'),('errors','Exact C locale diagnostics and status')]
plan={'acceptance':{'reference':'The original passes all scenarios against itself.','behavior':'The replacement matches stdout, stderr, exit status, and files for all scenarios.','quality':'Formatting, clippy, and unit tests pass.','coverage':'Each feature has tests. Unknown limits remain explicit.'},'features':[{'id':k,'interface':v,'contract':'The replacement matches bytes and status.','evidence':['E-'+k],'scenarios':'scenarios.json','task':'implement-'+k} for k,v in features],'tasks':[{'id':'implement-'+k,'depends_on':[] if k in ['encode','decode','options'] else ['implement-options'],'status':'ready'} for k,v in features],'milestones':['The parser supports complete CLI workflows.','The codec supports complete stdin and file workflows.','The validation passes exact comparisons.'],'gaps':['Signals, allocation failure, and other locales remain outside scope.'],'blocked_tasks':[]}
(p/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
(p/'rust-design.md').write_text('''# Rust design

The replacement uses the Rust standard library.
The project needs no external dependency.
The project rejects a CLI library because exact GNU errors need a small custom parser.
The parser uses byte arguments to preserve Unix filenames.
The parser supports GNU option permutation and POSIXLY_CORRECT.
The codec uses small state values and fixed buffers.
The encoder keeps its three-byte quantum across reads.
The decoder keeps its four-character quantum across reads.
The decoder emits partial bytes before it reports an error.
The output wrapper keeps a column counter.
The I/O layer reports errors at the CLI boundary.
The project uses safe Rust.
The project rejects a whole-file buffer because pipelines need bounded memory.
The recovered C procedure structure does not define Rust modules.
The initial implementation uses one small binary module.
The help and version resources preserve exact binary output.
The tests use tables and short readers to check state across boundaries.
The design preserves observed numeric overflow behavior.
The design treats source intent as unknown.
''')
