import pathlib,hashlib,json,datetime
p=pathlib.Path(__file__).parent
files={}
for path in sorted(p.rglob('*')):
 relative=path.relative_to(p)
 if not path.is_file() or 'target' in relative.parts or '__pycache__' in relative.parts or path.name=='freeze-manifest.json':continue
 data=path.read_bytes()
 files[str(relative)]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
binary=p/'replacement/target/release/base64'
manifest={'format':1,'frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stage':'The freeze precedes external evaluator and original source feedback.','source_access':'The reconstruction uses binary-only target evidence.','reference_sha256':'41dd92cf260491c5c8fc0084c42e58b1baaca9ebcc88aa38f60a17a2ef603570','candidate':{'path':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest()},'files':files}
(p/'freeze-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Frozen files:',len(files))
print('Candidate SHA-256:',manifest['candidate']['sha256'])
