import pathlib,subprocess,json,base64,os
p=pathlib.Path(__file__).parent
reference='/Users/runchao/Projects/Personal/rustify/work/downloads/base64'
candidate=str(p/'replacement/target/release/base64')
results=[]
def capture(binary,args,name=b'base64',data=b'',stdin_mode=None):
 r=subprocess.run([name,*args],executable=os.fsencode(binary),input=data if stdin_mode is None else None,stdin=stdin_mode,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env={'LC_ALL':'C','PATH':'/usr/bin:/bin'},cwd=p)
 return {'returncode':r.returncode,'stdout_b64':base64.b64encode(r.stdout).decode(),'stderr_b64':base64.b64encode(r.stderr).decode()}
def add(label,args,**kw):
 a=capture(reference,args,**kw);b=capture(candidate,args,**kw)
 results.append({'id':label,'args_b64':[base64.b64encode(x).decode() for x in args],'reference':a,'candidate':b,'passed':a==b})
for byte in [1,7,10,27,127,128,193,255]:
 add('raw-file-'+str(byte),[b'a'+bytes([byte])+b'b'])
 add('raw-wrap-'+str(byte),[b'-w',bytes([byte])])
for byte in [128,193,255]:
 add('raw-short-option-'+str(byte),[b'-'+bytes([byte])])
 add('raw-long-option-'+str(byte),[b'--'+bytes([byte])])
for name in [b'other',b'/tmp/other',b'./other',b'x/.libs/lt-base64',b'raw-\xff']:
 for args in [[b'--help'],[b'--version'],[b'-h']]:add('argv-zero-'+name.decode(errors='backslashreplace')+'-'+args[0].decode(),args,name=name)
for data in [b'a'*1000000,bytes(range(256))*4096]:
 for args in [[b'-w0'],[b'-w77']]:add('large-'+str(len(data))+'-'+args[0].decode(),args,data=data)
for r in json.loads((p/'evidence/quote-probes.json').read_text()):
 add('quote-'+str(len(results)),[os.fsencode(a) for a in r['args']])
(p/'extra-comparison.json').write_text(json.dumps({'status':'passed' if all(x['passed'] for x in results) else 'failed','passed':sum(x['passed'] for x in results),'failed':sum(not x['passed'] for x in results),'cases':results},indent=2)+'\n')
for x in results:
 if not x['passed']:print(x)
print('Cases:',len(results),'Failures:',sum(not x['passed'] for x in results))
