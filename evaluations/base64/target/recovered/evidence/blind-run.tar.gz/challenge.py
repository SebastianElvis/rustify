import pathlib,json,itertools,base64,random
p=pathlib.Path(__file__).parent
cases=[]
def add(args,data=b'',files=None):
 cases.append({'id':f'challenge-{len(cases):05d}','args':args,'stdin_b64':base64.b64encode(data).decode(),'files':{k:base64.b64encode(v).decode() for k,v in (files or {}).items()}})
for n in range(1,5):
 for symbols in itertools.product(b'AB/=\n!',repeat=n):
  for arg in ['-d','-di']:add([arg],bytes(symbols))
for b in range(256):
 for prefix in [b'',b'Y',b'YQ',b'YWJ',b'YQ==']:
  for arg in ['-d','-di']:add([arg],prefix+bytes([b])+b'YQ==')
for n in [4093,4094,4095,4096,4097,8191,8192,8193]:
 for suffix in [b'YQ==',b'YR==',b'YQ=',b'YQ',b'!',b'\xff']:
  for arg in ['-d','-di']:add([arg],b'A'*n+suffix)
for byte in range(1,128):
 name='a'+chr(byte)+'b'
 add([name]);add(['-w',name]);add(['x',name])
for options in itertools.product(['-d','-i','-w0','--decode','--wrap=2','--','file','--help','--bad'],repeat=2):
 add(list(options),b'YWJj',{'file':b'YQ=='})
(p/'challenge-scenarios.json').write_text(json.dumps(cases,indent=2)+'\n')
print(len(cases))
