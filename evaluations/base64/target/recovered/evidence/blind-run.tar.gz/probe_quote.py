import pathlib,subprocess,json,base64
p=pathlib.Path(__file__).parent;b='/Users/runchao/Projects/Personal/rustify/work/downloads/base64'
r=[]
for ch in range(32,127):
 for name in [chr(ch),chr(ch)+'a','a'+chr(ch),'a'+chr(ch)+'b']:
  if name.startswith('-'): args=['--',name]
  else:args=[name]
  x=subprocess.run(['base64',*args],executable=b,capture_output=True,env={'LC_ALL':'C'},cwd=p)
  r.append({'args':args,'stderr_b64':base64.b64encode(x.stderr).decode()})
  if ch in b'#={}~]': print(repr(name),repr(x.stderr))
(p/'evidence/quote-probes.json').write_text(json.dumps(r,indent=2)+'\n')
