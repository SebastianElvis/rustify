# Base64 replacement

The replacement implements the tested GNU coreutils 9.12 base64 CLI.
The project targets macOS arm64 in the C locale.

The user can run `python3 check.py` to build and check the replacement.
The user can run `replacement/target/release/base64 --help` to inspect the CLI.
The user can run `python3 extra_tests.py` and `python3 write_tests.py` for supplementary comparisons.
The user can run the Rustify comparison helper with `scenarios.json` or `challenge-scenarios.json`.

The file `compatibility.md` states test counts and limits.
The file `checks.json` records build commands and explicit linker flags.
The file `state.json` records checkpoints.
The file `freeze-manifest.json` freezes source and discovery evidence before external evaluation.
The directory `evidence/` stores raw observations and initial failures.
The file `evidence/rea.json` stores exported REA evidence.
The file `evidence/rea-snapshot.json` stores the closed REA analysis snapshot.
The project uses no external Rust dependency.
