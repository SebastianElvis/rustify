import pathlib,subprocess,json,os
p=pathlib.Path(__file__).parent
checks=[]
build_env=dict(os.environ,RUSTFLAGS="-C linker=/usr/bin/clang -C link-arg=-fuse-ld=/usr/bin/ld")
for command in [['cargo','fmt','--check'],['cargo','clippy','--all-targets','--','-D','warnings'],['cargo','test'],['cargo','build','--release']]:
 r=subprocess.run(command,cwd=p/'replacement',capture_output=True,text=True,env=build_env)
 log='evidence/'+command[1]+'.log'
 (p/log).write_text(r.stdout+r.stderr)
 checks.append({'command':command,'environment':{'RUSTFLAGS':build_env['RUSTFLAGS']},'status':'passed' if r.returncode==0 else 'failed','returncode':r.returncode,'log':log})
 print(command,r.returncode)
(p/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
raise SystemExit(any(r['returncode'] for r in checks))
