import pathlib,json
p=pathlib.Path(__file__).parent
contract=json.loads((p/'contract.json').read_text())
contract['exclusions'] += ['Exact descriptor exhaustion behavior. The command duplicates stdout.','Closed standard descriptors at process startup. The Rust runtime can repair them.','Nonblocking descriptor scheduling and read interruption timing.']
(p/'contract.json').write_text(json.dumps(contract,indent=2)+'\n')
evidence=json.loads((p/'evidence.json').read_text())
evidence.extend([
 {'id':'E-missing-padding','claim':'The decoder accepts missing padding if the remaining pad bits are zero. The decoder rejects a single missing padding byte after an explicit equals sign.','classification':'observed','source':['comparison.json','challenge-comparison.json','evidence/initial-mismatches.json'],'limitations':'The scenarios cover finite groups and boundaries.'},
 {'id':'E-write-failure','claim':'The command reports write failure. The command can report invalid input before a final write failure.','classification':'observed','source':['evidence/write-errors.json','write-comparison.json'],'limitations':'The test uses a read-only stdout descriptor.'},
 {'id':'E-numeric','claim':'The wrap parser accepts C leading whitespace. The parser maps positive signed overflow to zero. The parser rejects negative nonzero sizes.','classification':'observed','source':['evidence/more-probes.json','comparison.json'],'limitations':'The largest tested token has 31 digits.'}
])
(p/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
with (p/'product.md').open('a') as f:f.write('''
The decoder can infer missing padding when the remaining pad bits are zero.
The decoder rejects missing explicit padding completion.
The evidence record is `E-missing-padding`.
The numeric parser accepts C leading whitespace.
The numeric parser disables wrapping for positive signed overflow.
The evidence record is `E-numeric`.
The output path reports write failures.
The output path can report invalid input before a final write failure.
The evidence record is `E-write-failure`.
''')
with (p/'rust-design.md').open('a') as f:f.write('''
The replacement duplicates stdout into an owned File descriptor.
This choice prevents Rust stdout from suppressing EBADF write failures.
The replacement reports an input error before a final output error.
The replacement removes duplicate write diagnostics.
The project excludes descriptor exhaustion and closed startup descriptors.
The host linker settings changed during the investigation.
The check script selects the Apple linker explicitly.
The project preserves the failed linker output in `evidence/toolchain-failure-test.log`.
''')
plan=json.loads((p/'plan.json').read_text());scenarios=json.loads((p/'scenarios.json').read_text())
for feature in plan['features']:
 k=feature['id']
 selected=[]
 for c in scenarios:
  args=c['args'];text=' '.join(args)
  match={'encode':not args or '-w' in text,'decode':'-d' in text,'input':bool(c['files']) or args==['missing'],'wrap':'-w' in text,'garbage':'-di' in text or '--ignore' in text,'options':any(x.startswith('-') for x in args),'information':'--help' in text or '--version' in text,'errors':args in [['-h'],['--wat'],['missing'],['.'],['a','b']]}.get(k,False)
  if match:selected.append(c['id'])
 feature['scenarios']=selected
 if k=='decode':feature['evidence'].append('E-missing-padding')
 if k=='wrap':feature['evidence'].append('E-numeric')
 if k=='errors':feature['evidence'].append('E-write-failure')
(p/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
(p/'compatibility.md').write_text('''# Compatibility report

The replacement passes all scoped acceptance checks.
The command uses the Rust standard library only.
The project has no upstream source access.
The project uses the supplied binary as its behavioral reference.

| Check | Result |
| --- | --- |
| Unit tests | 10 tests pass. |
| Initial E2E scenarios | 1490 cases pass. |
| Separate generated E2E scenarios | 6226 cases pass. |
| Raw arguments, names, large input, and quoting | 421 cases pass. |
| Write failures | 8 cases pass. |
| Reference repeatability | 7716 cases pass. |
| Formatting and clippy | Both checks pass. |

The E2E checks total 8145 cases.
The comparison helper checks stdout, stderr, status, and fixture files exactly.
The supplementary checks use raw Unix arguments and descriptor failures.
The comparison reports preserve raw bytes.
The largest tested input has 1048576 bytes.
The scenario count includes related and repeated cases.
The count does not measure unique behavior or prove arbitrary input equivalence.

The command supports encoding, decoding, stdin, dash, one file, wrapping, and garbage filtering.
The command supports long option prefixes, short option groups, option ordering, help, and version.
The command preserves partial decoder output.
The command checks padding placement and zero pad bits.
The command accepts canonical missing padding and concatenated groups.
The command reproduces the tested C locale diagnostics.

The first comparison found missing-padding and whitespace defects.
The separate generated cases found seven filename-quoting defects.
The supplementary tests found Rust stdout suppression of EBADF errors.
The project repaired these replacement defects before the freeze.
The project preserves initial mismatch reports in `evidence/`.
The fixes came from binary observations.
The project received no original source or external evaluator feedback.

The contract limits coverage to macOS arm64 in the C locale.
Other locales and operating systems remain outside scope.
The tests do not establish exact signal behavior, interactive timing, or interruption behavior.
The tests do not inject allocation or descriptor exhaustion.
The Rust runtime can repair closed startup descriptors.
The project excludes that startup behavior.
The tests do not establish exact nonblocking descriptor scheduling.
The implementation uses bounded buffers.
The investigation does not prove a performance bound.

REA supplied Mach-O and Hopper pseudocode evidence.
The project exported the evidence and closed the REA session.
The recovered architecture remains separate from the Rust design.
The pseudocode does not prove all machine-level details.
The project records all knowledge limits in `contract.json` and `evidence.json`.

The host linker settings changed during the investigation.
The check script sets explicit Apple linker flags.
The project preserves the failed host linker logs.
The skill helpers showed no defect during this run.
''')
(p/'README.md').write_text('''# Base64 replacement

The replacement implements the tested GNU coreutils 9.12 base64 CLI.
The project targets macOS arm64 in the C locale.

The user can run `python3 check.py` to build and check the replacement.
The user can run `replacement/target/release/base64 --help` to inspect the CLI.
The user can run `python3 extra_tests.py` and `python3 write_tests.py` for supplementary comparisons.
The user can run the Rustify comparison helper with `scenarios.json` or `challenge-scenarios.json`.

The file `compatibility.md` states test counts and limits.
The file `checks.json` records build commands and explicit linker flags.
The file `state.json` records checkpoints.
The file `freeze-manifest.json` freezes source and discovery evidence before external evaluation.
The directory `evidence/` stores raw observations and initial failures.
The file `evidence/rea.json` stores exported REA evidence.
The file `evidence/rea-snapshot.json` stores the closed REA analysis snapshot.
The project uses no external Rust dependency.
''')
(p/'isolation.md').write_text('''# Source isolation

The reconstruction reads the Rustify entrypoint, docs, and scripts.
The reconstruction reads the supplied executable and its own target project.
The reconstruction uses host tools and binary probes.
The reconstruction uses REA against the supplied executable.
The reconstruction reads no upstream source, upstream test suite, evaluation directory, or other worker conclusions.
The reconstruction uses no internet source code.
The parent reports host application availability and license status.
Those reports do not supply target behavior or implementation details.
The project creates no repository, commit, push, or skill installation.
The project changes no skill helper.
The freeze precedes all external evaluation and source feedback.
''')
