import probe,json,base64
r=[]
for s in ['2147483647','2147483648','9223372036854775807','9223372036854775808','999999999999999999999999999999999','-0','-00',' -0','\t+2','+','0x10','00','\n1','  ','-9223372036854775809']:
 r.append(probe.run(['-w',s],b'a'))
for s in ['YQ=A','YR=A','YWA=','YWK=','YQ=\n=','YQ\n==','YWJjY','YWJjYW','YWJjYWJ','YQ=\n','YQ==\n\n','A===','AA=A','AAA=AAAA','YR==YQ==','YQ=!==']:
 for o in [['-d'],['-di']]:r.append(probe.run(o,s.encode()))
for a in [['-'],['--='],['--d=1'],['--w='],['--ign'],['-D'],['-?'],['--','a','b'],['a','--bad'],['a','-w','2','b'],['-w','2','-w','0'],['-w','2','-i'],['--he'],['--v']]:r.append(probe.run(a,b'abc'))
for name in ['foo bar',"foo'bar",'foo"bar','foo:bar','foo\nbar','foo\\bar','foo\tbar','é',"'",'']:
 r.append(probe.run([name]))
 r.append(probe.run(['-w',name]))
(probe.root/'evidence/more-probes.json').write_text(json.dumps(r,indent=2)+'\n')
for x in r:print(x['args'],base64.b64decode(x['stdin_b64']),x['status'],repr(base64.b64decode(x['stdout_b64'])),repr(base64.b64decode(x['stderr_b64'])))
