import subprocess,json,pathlib,base64
p=pathlib.Path(__file__).parent
b='/Users/runchao/Projects/Personal/rustify/work/downloads/base64'
r=[]
for name in ['other','/tmp/other','./other','x/y/base64','lt-base64','x/.libs/lt-base64']:
 for a in [['--help'],['-h'],['--version']]:
  q=subprocess.run([name,*a],executable=b,capture_output=True,env={'LC_ALL':'C'})
  r.append({'name':name,'args':a,'status':q.returncode,'stdout_b64':base64.b64encode(q.stdout).decode(),'stderr_b64':base64.b64encode(q.stderr).decode()})
  print(name,a,repr(q.stdout[:70]),repr(q.stderr))
(p/'evidence/names.json').write_text(json.dumps(r,indent=2)+'\n')
