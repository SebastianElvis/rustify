import pathlib,subprocess,json,base64
p=pathlib.Path(__file__).parent
r=[]
q=p/'evidence/readonly-output'
q.write_bytes(b'')
for args,data in [([],b'abc'),(['--help'],b''),(['--version'],b''),(['-d'],b'YQ=='),(['-d'],b'YQ!'),([],b'a'*10000),(['-d'],b'YQ=='*2000),(['-h'],b'')]:
 out={}
 for side,b in [('reference','/Users/runchao/Projects/Personal/rustify/work/downloads/base64'),('candidate',str(p/'replacement/target/release/base64'))]:
  with q.open('rb') as f:
   x=subprocess.run(['base64',*args],executable=b,input=data,stdout=f,stderr=subprocess.PIPE,env={'LC_ALL':'C'})
   out[side]={'status':x.returncode,'stderr_b64':base64.b64encode(x.stderr).decode()}
 r.append({'args':args,'stdin_b64':base64.b64encode(data).decode(),'stdout':'A read-only regular descriptor forces EBADF.',**out,'passed':out['reference']==out['candidate']})
q.unlink()
report={'status':'passed' if all(x['passed'] for x in r) else 'failed','passed':sum(x['passed'] for x in r),'failed':sum(not x['passed'] for x in r),'cases':r}
(p/'write-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print({k:report[k] for k in ['status','passed','failed']})
