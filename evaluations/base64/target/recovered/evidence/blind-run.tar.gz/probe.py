import subprocess,json,base64,os,pathlib
root=pathlib.Path(__file__).parent
binary='/Users/runchao/Projects/Personal/rustify/work/downloads/base64'
def run(args,data=b''):
 p=subprocess.run(['base64',*args],executable=binary,input=data,capture_output=True,env={'LC_ALL':'C','PATH':'/usr/bin:/bin'},cwd=root)
 return {'args':args,'stdin_b64':base64.b64encode(data).decode(),'status':p.returncode,'stdout_b64':base64.b64encode(p.stdout).decode(),'stderr_b64':base64.b64encode(p.stderr).decode()}
args=[['--help'],['--version'],['-h'],['--wat'],['--dec'],['--i'],['--w'],['-w'],['--wrap'],['--wrap='],['-w','-1'],['-w','+1'],['-w',' 1'],['-w','1 '],['-w','01'],['-w','1k'],['-w','18446744073709551615'],['-w','18446744073709551616'],['a','b'],['missing'],['.'],['-di'],['--decode=1'],['--help=1'],['--version=1'],['--wrap','--help'],['--help','--bad'],['--bad','--help'],['-dw0'],['--','-d'],['foo','-d'],['foo','bar','--help']]
records=[run(a,b'YWJj\n') for a in args]
for data in [b'',b'Y',b'YW',b'YWJ',b'YWJj',b'YQ=',b'YQ==',b'YQ===',b'YQ==Yg==',b'YQ==\nYg==',b'YQ==A',b'YQ==!',b'YQ!Yg',b'YWJj!',b'YWJj!YQ==',b'YQ\r==',b'Y Q==',b'YQ\t==',b'=YQ=',b'====',b'YR==',b'YWK=',b'\xffYQ==']:
 for opts in [['-d'],['-di']]:records.append(run(opts,data))
(root/'evidence/probes.json').write_text(json.dumps(records,indent=2)+'\n')
for r in records: print(r['args'],base64.b64decode(r['stdin_b64']),r['status'],repr(base64.b64decode(r['stdout_b64'])),repr(base64.b64decode(r['stderr_b64'])))
