# Compatibility report

The replacement passes all scoped acceptance checks.
The command uses the Rust standard library only.
The project has no upstream source access.
The project uses the supplied binary as its behavioral reference.

| Check | Result |
| --- | --- |
| Unit tests | 10 tests pass. |
| Initial E2E scenarios | 1490 cases pass. |
| Separate generated E2E scenarios | 6226 cases pass. |
| Raw arguments, names, large input, and quoting | 421 cases pass. |
| Write failures | 8 cases pass. |
| Reference repeatability | 7716 cases pass. |
| Formatting and clippy | Both checks pass. |

The E2E checks total 8145 cases.
The comparison helper checks stdout, stderr, status, and fixture files exactly.
The supplementary checks use raw Unix arguments and descriptor failures.
The comparison reports preserve raw bytes.
The largest tested input has 1048576 bytes.
The scenario count includes related and repeated cases.
The count does not measure unique behavior or prove arbitrary input equivalence.

The command supports encoding, decoding, stdin, dash, one file, wrapping, and garbage filtering.
The command supports long option prefixes, short option groups, option ordering, help, and version.
The command preserves partial decoder output.
The command checks padding placement and zero pad bits.
The command accepts canonical missing padding and concatenated groups.
The command reproduces the tested C locale diagnostics.

The first comparison found missing-padding and whitespace defects.
The separate generated cases found seven filename-quoting defects.
The supplementary tests found Rust stdout suppression of EBADF errors.
The project repaired these replacement defects before the freeze.
The project preserves initial mismatch reports in `evidence/`.
The fixes came from binary observations.
The project received no original source or external evaluator feedback.

The contract limits coverage to macOS arm64 in the C locale.
Other locales and operating systems remain outside scope.
The tests do not establish exact signal behavior, interactive timing, or interruption behavior.
The tests do not inject allocation or descriptor exhaustion.
The Rust runtime can repair closed startup descriptors.
The project excludes that startup behavior.
The tests do not establish exact nonblocking descriptor scheduling.
The implementation uses bounded buffers.
The investigation does not prove a performance bound.

REA supplied Mach-O and Hopper pseudocode evidence.
The project exported the evidence and closed the REA session.
The recovered architecture remains separate from the Rust design.
The pseudocode does not prove all machine-level details.
The project records all knowledge limits in `contract.json` and `evidence.json`.

The host linker settings changed during the investigation.
The check script sets explicit Apple linker flags.
The project preserves the failed host linker logs.
The skill helpers showed no defect during this run.
