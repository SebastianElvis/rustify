# Source isolation

The reconstruction reads the Rustify entrypoint, docs, and scripts.
The reconstruction reads the supplied executable and its own target project.
The reconstruction uses host tools and binary probes.
The reconstruction uses REA against the supplied executable.
The reconstruction reads no upstream source, upstream test suite, evaluation directory, or other worker conclusions.
The reconstruction uses no internet source code.
The parent reports host application availability and license status.
Those reports do not supply target behavior or implementation details.
The project creates no repository, commit, push, or skill installation.
The project changes no skill helper.
The freeze precedes all external evaluation and source feedback.
